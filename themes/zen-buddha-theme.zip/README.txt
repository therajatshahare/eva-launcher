Zen Buddha theme for EVA Launcher
=================================
Serene watercolor Buddha artwork with soft lotus tones and smooth motion.

Files
  config.json    theme configuration
  wallpaper.jpg  default Buddha watercolor wallpaper
  wallpapers/    buddha_zen.jpg
