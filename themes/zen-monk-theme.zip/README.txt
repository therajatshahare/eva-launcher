Zen Monk theme for EVA Launcher
===============================
Serene watercolor meditating monk under cherry blossom tree with circular icons, warm ivory palette, 100% dock opacity, and smooth animations.

Files
  config.json    theme configuration
  wallpaper.jpg  default meditating monk watercolor artwork
  wallpapers/    zen_monk.jpg
