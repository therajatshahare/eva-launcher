Theme: Zen Monk
Author: Rajat Shahare
Greeting Name: Rajat Shahare
Dock Opacity: 100%
Rows Below Dock: 0
Circle Tiles: True
Wallpaper True Color: True
Description: Serene watercolor meditating monk under cherry blossoms with true circular icons, warm parchment ivory palette, 100% dock opacity, and smooth animations.
