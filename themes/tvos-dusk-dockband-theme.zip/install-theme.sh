#!/bin/sh
# Pushes this theme to a TV over adb and restarts the launcher.
# Usage: ./install-theme.sh            (grid look)   |   ./install-theme.sh dock-band
set -e
pkg=io.rns.evalauncher
uri="content://$pkg.theme"
here=$(cd "$(dirname "$0")" && pwd)
config=config.json; [ "$1" = dock-band ] && config=config.dock-band.json
push() { adb push "$1" /data/local/tmp/theme_tmp >/dev/null; adb shell "content write --uri $uri/$2 < /data/local/tmp/theme_tmp"; echo "wrote $2"; }
push "$here/$config" config.json
push "$here/wallpaper.jpg" wallpaper.jpg
for f in "$here"/wallpapers/*.jpg; do push "$f" "wallpapers/$(basename "$f")"; done
adb shell "rm -f /data/local/tmp/theme_tmp; am force-stop $pkg; input keyevent KEYCODE_HOME"
