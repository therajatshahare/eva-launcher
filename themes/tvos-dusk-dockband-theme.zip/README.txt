TV OS Dusk theme for EVA Launcher
==================================
Files
  config.json            the theme (grid look, matches the reference picture)
  config.dock-band.json  alternative: glass dock band + 2 rows below (rename to config.json to use by hand)
  wallpaper.jpg          default wallpaper (purple / rose gradient, 1920x1080)
  wallpapers/            dusk, ocean, ember: shown in Launcher settings > Wallpaper & Themes

Install with adb (Windows PowerShell, TV connected with adb):
  .\install-theme.ps1              grid look
  .\install-theme.ps1 -DockBand    glass dock band variant

No adb? Copy config.json, wallpaper.jpg and the wallpapers folder into
  Android/data/io.rns.evalauncher/files/
with a TV file manager, then restart the launcher (force stop, press Home).

Edit "greeting_name" in config.json to change the name after the greeting.
If you ever changed "Apps per row" in Launcher settings, that saved value overrides "columns".
