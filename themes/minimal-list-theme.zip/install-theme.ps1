# Pushes this theme to a TV over adb and restarts the launcher.
# Usage:  .\install-theme.ps1
$pkg = 'io.rns.evalauncher'
$uri = "content://$pkg.theme"
$here = $PSScriptRoot

function Push-File($local, $remoteName) {
    adb push "$local" "/data/local/tmp/theme_tmp" | Out-Null
    adb shell "content write --uri $uri/$remoteName < /data/local/tmp/theme_tmp"
    Write-Host "wrote $remoteName"
}

Push-File (Join-Path $here 'config.json') 'config.json'
Push-File (Join-Path $here 'wallpaper.jpg') 'wallpaper.jpg'
foreach ($img in Get-ChildItem (Join-Path $here 'wallpapers') -Filter *.jpg) {
    Push-File $img.FullName "wallpapers/$($img.Name)"
}
adb shell "rm -f /data/local/tmp/theme_tmp"
adb shell "am force-stop $pkg"
adb shell "input keyevent KEYCODE_HOME"
Write-Host "Done. Open Launcher settings > Wallpaper & Themes to pick another wallpaper."
