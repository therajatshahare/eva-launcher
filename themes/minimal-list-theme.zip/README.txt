EVA Minimal List theme for EVA Launcher
=======================================
Apps as a single vertical list of names: no icons, no tiles. Move Up/Down and a thin
outlined bar follows the name you are on; the name brightens and slides in a little.

REQUIRES a launcher build that has the "list_layout" option (added together with this
theme). An older launcher ignores that key and shows the normal grid.

Files
  config.json      the theme ("list_layout": true plus a quiet header)
  wallpaper.jpg    default wallpaper (midnight, dark blue, 1920x1080)
  wallpapers/      midnight, ember, moss, slate: pick in Launcher settings > Wallpaper & Themes

Install with adb:
  Windows PowerShell:  .\install-theme.ps1
  macOS / Linux:       ./install-theme.sh

No adb? Copy config.json, wallpaper.jpg and the wallpapers folder into
  Android/data/io.rns.evalauncher/files/
with a TV file manager, then restart the launcher (force stop, press Home).

Edit "greeting_name" in config.json to change the name after the greeting.
list_layout always uses one column, so "Apps per row" and "Rows below the dock" in
Launcher settings have no effect while it is on. Remove "list_layout" (or set it to
false) to go back to a grid.
